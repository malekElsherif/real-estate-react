import { useNavigate } from "react-router-dom";
import { usegetme } from "../../hooks/useUsers";
import {
  DEFAULT_ADMIN_PREFS,
  btnDark,
  btnOutline,
  btnPad,
  roleBadgeClass,
  useAdminPrefs,
} from "./adminBrand";

type ToggleProps = {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
};

const Toggle = ({ checked, onChange, label }: ToggleProps) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    aria-label={label}
    onClick={() => onChange(!checked)}
    className={`relative h-6 w-11 shrink-0 border transition ${
      checked
        ? "border-[#B8863B] bg-[#B8863B]"
        : "border-[#14213D]/30 bg-[#14213D]/10"
    }`}
  >
    <span
      className={`absolute top-0.5 h-4 w-4 bg-white transition-all ${
        checked ? "left-6" : "left-0.5"
      }`}
    />
  </button>
);

const Settings = () => {
  const navigate = useNavigate();
  const [prefs, updatePrefs] = useAdminPrefs();

  const { data: meData, isLoading, isError } = usegetme();
  const me = meData?.data ?? meData;

  const profileFields = [
    { label: "Full Name", value: me?.name || "—" },
    { label: "Email Address", value: me?.email || "—", breakAll: true },
    { label: "Account ID", value: me?.id != null ? `#${me.id}` : "—" },
  ];

  const prefRows = [
    {
      key: "sidebarOpen" as const,
      title: "Open sidebar on start",
      text: "Keep the navigation sidebar open when the console loads on desktop.",
    },
    {
      key: "compact" as const,
      title: "Compact tables",
      text: "Use tighter row spacing in every table to fit more records on screen.",
    },
  ];

  return (
    <div className="mx-auto max-w-4xl">
      {/* Title */}
      <div className="mb-8">
        <p className="eyebrow text-[#B8863B]">System</p>

        <h1 className="font-heading mt-2 text-3xl font-semibold text-[#14213D] sm:text-4xl">
          Settings
        </h1>

        <p className="mt-2 text-xs text-[#14213D]/60">
          Your administrator profile and console preferences.
        </p>

        <div className="mt-4 h-px w-16 bg-[#B8863B]" />
      </div>

      <div className="space-y-6">
        {/* Profile */}
        <section className="border border-[#14213D]/15 bg-white p-7">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#E4DFD3] pb-5">
            <div>
              <h2 className="font-heading text-2xl font-semibold">Profile</h2>
              <p className="eyebrow mt-1 text-[#14213D]/45">
                Signed-in administrator
              </p>
            </div>

            <span
              className={`eyebrow border px-2.5 py-1 font-semibold ${roleBadgeClass(
                me?.role || "ADMIN"
              )}`}
            >
              {me?.role || "ADMIN"}
            </span>
          </div>

          {isLoading ? (
            <p className="mt-6 text-xs text-[#14213D]/60">Loading profile...</p>
          ) : isError ? (
            <p className="mt-6 text-xs text-[#B8452E]">
              Failed to load your profile.
            </p>
          ) : (
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              {profileFields.map((field) => (
                <div
                  key={field.label}
                  className="border border-[#E4DFD3] bg-[#FFFDF9] p-5"
                >
                  <p className="eyebrow text-[#14213D]/50">{field.label}</p>

                  <p
                    className={`mt-2 text-sm font-semibold text-[#14213D] ${
                      field.breakAll ? "break-all" : ""
                    }`}
                  >
                    {field.value}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Interface preferences */}
        <section className="border border-[#14213D]/15 bg-white p-7">
          <div className="border-b border-[#E4DFD3] pb-5">
            <h2 className="font-heading text-2xl font-semibold">Interface</h2>
            <p className="eyebrow mt-1 text-[#14213D]/45">
              Saved automatically on this device
            </p>
          </div>

          <div className="divide-y divide-[#E4DFD3]">
            {prefRows.map((row) => (
              <div
                key={row.key}
                className="flex items-center justify-between gap-6 py-5"
              >
                <div>
                  <p className="text-sm font-semibold text-[#14213D]">
                    {row.title}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-[#4A5568]">
                    {row.text}
                  </p>
                </div>

                <Toggle
                  label={row.title}
                  checked={prefs[row.key]}
                  onChange={(value) => updatePrefs({ [row.key]: value })}
                />
              </div>
            ))}
          </div>

          <div className="border-t border-[#E4DFD3] pt-5">
            <button
              type="button"
              onClick={() => updatePrefs(DEFAULT_ADMIN_PREFS)}
              className={`${btnPad} ${btnOutline}`}
            >
              Reset to defaults
            </button>
          </div>
        </section>

        {/* Quick links */}
        <section className="border border-[#14213D]/15 bg-white p-7">
          <div className="border-b border-[#E4DFD3] pb-5">
            <h2 className="font-heading text-2xl font-semibold">Navigation</h2>
            <p className="eyebrow mt-1 text-[#14213D]/45">Jump to</p>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => navigate("/admin/dashboard")}
              className={`${btnPad} ${btnDark}`}
            >
              Dashboard
            </button>

            <button
              type="button"
              onClick={() => navigate("/")}
              className={`${btnPad} ${btnOutline}`}
            >
              Back to website
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Settings;
