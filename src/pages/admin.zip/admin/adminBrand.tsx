/**
 * Shared brand tokens for the admin area
 * navy  #14213D  -> primary / dark base
 * cream #FFFDF9  -> background
 * gold  #B8863B  -> accent / CTA
 * line  #E4DFD3  -> hairline borders
 * green #5B7B65  -> positive      red #B8452E -> destructive
 */

export const BrandStyles = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

    .brand-root { font-family: 'IBM Plex Mono', ui-monospace, monospace; }
    .font-heading { font-family: 'Fraunces', Georgia, serif; letter-spacing: -0.01em; }
    .font-data { font-family: 'IBM Plex Mono', ui-monospace, monospace; }
    .eyebrow {
      font-family: 'IBM Plex Mono', ui-monospace, monospace;
      font-size: 0.65rem;
      letter-spacing: 0.16em;
      text-transform: uppercase;
    }
  `}</style>
);

/* ---------- Buttons (compose with btnPad / btnPadSm) ---------- */
export const btnPad = "px-4 py-2.5";
export const btnPadSm = "px-3 py-2";

const btnBase =
  "eyebrow font-semibold transition disabled:cursor-not-allowed disabled:opacity-50";

export const btnPrimary = `${btnBase} bg-[#B8863B] text-white hover:bg-[#a37632]`;
export const btnDark = `${btnBase} bg-[#14213D] text-[#FFFDF9] hover:bg-[#B8863B]`;
export const btnSuccess = `${btnBase} bg-[#5B7B65] text-[#FFFDF9] hover:bg-[#4a6652]`;
export const btnOutline = `${btnBase} border border-[#14213D] text-[#14213D] hover:bg-[#14213D] hover:text-[#FFFDF9]`;
export const btnGold = `${btnBase} border border-[#B8863B] text-[#B8863B] hover:bg-[#B8863B] hover:text-white`;
export const btnDanger = `${btnBase} border border-[#B8452E] text-[#B8452E] hover:bg-[#B8452E] hover:text-[#FFFDF9]`;
export const btnDangerSolid = `${btnBase} bg-[#B8452E] text-[#FFFDF9] hover:bg-[#9c3a26]`;

/* ---------- Form controls ---------- */
export const inputClass =
  "font-data w-full border border-[#E4DFD3] bg-[#FFFDF9] px-4 py-2.5 text-xs text-[#14213D] placeholder-[#4A5568] outline-none transition focus:border-[#14213D]";

/* ---------- Roles ---------- */
export const roleBadgeClass = (role?: string) =>
  role === "ADMIN"
    ? "border-[#14213D] bg-[#14213D] text-[#FFFDF9]"
    : role === "AGENT"
    ? "border-[#B8863B] bg-[#B8863B]/10 text-[#B8863B]"
    : "border-[#14213D]/30 text-[#14213D]";

export const roleAvatarClass = (role?: string) =>
  role === "ADMIN"
    ? "bg-[#14213D] text-[#FFFDF9]"
    : role === "AGENT"
    ? "bg-[#B8863B] text-white"
    : "bg-[#14213D]/10 text-[#14213D]";

export const roleLabel = (role?: string) =>
  role === "AGENT"
    ? "Estate Agent"
    : role === "ADMIN"
    ? "Platform Admin"
    : "Registered Client";

/* ---------- Status pills ---------- */
export const activePill =
  "eyebrow inline-flex items-center gap-2 border border-[#5B7B65] bg-[#5B7B65]/10 px-2.5 py-1 font-semibold text-[#5B7B65]";
export const inactivePill =
  "eyebrow inline-flex items-center gap-2 border border-[#B8452E] bg-[#B8452E]/10 px-2.5 py-1 font-semibold text-[#B8452E]";

/* ---------- Pagination (rc-pagination) ---------- */
export const paginationClass =
  "flex gap-2 text-xs font-medium cursor-pointer [&_.rc-pagination-item]:px-3 [&_.rc-pagination-item]:py-1 [&_.rc-pagination-item]:border [&_.rc-pagination-item]:border-[#E4DFD3] [&_.rc-pagination-item:hover]:border-[#14213D] [&_.rc-pagination-item-active]:bg-[#14213D] [&_.rc-pagination-item-active]:text-[#FFFDF9] [&_.rc-pagination-item-active]:border-[#14213D]";
