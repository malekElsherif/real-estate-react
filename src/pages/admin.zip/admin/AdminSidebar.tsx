import { useLocation, useNavigate } from "react-router-dom";

const sections = [
  {
    title: "Overview",
    items: [{ label: "Dashboard", path: "/admin/dashboard" }],
  },
  {
    title: "User Management",
    items: [{ label: "Manage Users", path: "/admin/dashboard/users/manage" }],
  },
  {
    title: "Management",
    items: [
      { label: "Properties", path: "/admin/dashboard/properties" },
      { label: "Requests", path: "/admin/dashboard/requests" },
    ],
  },
  {
    title: "System",
    items: [{ label: "Settings", path: "/admin/dashboard/settings" }],
  },
];

const AdminSidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <aside className="brand-root fixed left-0 top-0 z-40 flex h-screen w-72 flex-col border-r border-[#B8863B]/30 bg-[#14213D]">
      {/* Logo */}
      <div className="flex h-20 items-center border-b border-[#FFFDF9]/10 px-6">
        <div className="flex items-center gap-3">
          <div className="font-heading flex h-10 w-10 shrink-0 items-center justify-center border border-[#B8863B] text-xl font-semibold text-[#B8863B]">
            A
          </div>

          <div className="whitespace-nowrap">
            <p className="font-heading text-lg font-semibold leading-tight text-[#FFFDF9]">
              Admin Panel
            </p>

            <p className="eyebrow text-[#FFFDF9]/50">Estate Management</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-4 py-6">
        {sections.map((section, index) => (
          <div key={section.title}>
            <p
              className={`eyebrow mb-3 px-3 text-[#B8863B] ${
                index === 0 ? "" : "mt-8"
              }`}
            >
              {section.title}
            </p>

            {section.items.map((item) => {
              const active = isActive(item.path);

              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`mb-1 flex w-full items-center gap-3 border-l-2 px-4 py-3 text-left text-xs font-medium uppercase tracking-wider transition ${
                    active
                      ? "border-[#B8863B] bg-[#FFFDF9]/8 text-[#B8863B]"
                      : "border-transparent text-[#FFFDF9]/70 hover:border-[#B8863B]/50 hover:text-[#FFFDF9]"
                  }`}
                >
                  <span
                    className={`h-1.5 w-1.5 ${
                      active ? "bg-[#B8863B]" : "bg-[#FFFDF9]/25"
                    }`}
                  />
                  {item.label}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-[#FFFDF9]/10 p-4">
        <button
          onClick={() => navigate("/")}
          className="flex w-full items-center gap-3 border border-[#FFFDF9]/20 px-4 py-3 text-xs font-medium uppercase tracking-wider text-[#FFFDF9]/80 transition hover:border-[#B8863B] hover:text-[#B8863B]"
        >
          ← Back to Website
        </button>
      </div>
    </aside>
  );
};

export default AdminSidebar;
