import { useState } from "react";
import { Outlet, useLocation, Link } from "react-router-dom";
import AdminSidebar from "./AdminSidebar";
import { BrandStyles } from "./adminBrand";

export const AdminLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const location = useLocation();

  const pathSegments = location.pathname.split("/").filter(Boolean);

  const currentPathName =
    pathSegments[pathSegments.length - 1] || "dashboard";

  const formattedTitle = currentPathName
    .replace(/-/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());

  return (
    <div className="brand-root min-h-screen bg-[#FFFDF9] text-[#14213D] antialiased">
      {/* Fonts + shared classes for the whole admin area (also reach MUI dialogs) */}
      <BrandStyles />

      {/* Overlay - Mobile */}
      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 z-40 bg-[#14213D]/50 backdrop-blur-sm lg:hidden"
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed inset-y-0 left-0 z-50
          w-72 bg-[#14213D]
          transition-transform duration-300 ease-in-out
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
        `}
      >
        <AdminSidebar />
      </aside>

      {/* Main Wrapper */}
      <div
        className={`
          min-h-screen
          transition-all duration-300 ease-in-out
          ${sidebarOpen ? "lg:ml-72" : "lg:ml-0"}
        `}
      >
        {/* Header */}
        <header
          className="
            sticky top-0 z-30
            flex h-16 items-center justify-between
            border-b border-[#14213D]/10
            bg-[#FFFDF9]/90
            px-4 sm:px-6 lg:px-8
            backdrop-blur-md
          "
        >
          {/* Left Side */}
          <div className="flex items-center gap-4">
            {/* Sidebar Toggle */}
            <button
              onClick={() => setSidebarOpen((prev) => !prev)}
              type="button"
              className="inline-flex h-9 w-9 items-center justify-center border border-[#14213D]/20 bg-[#FFFDF9] text-[#14213D] transition hover:border-[#B8863B] hover:text-[#B8863B] active:scale-95"
              aria-label="Toggle navigation menu"
            >
              {sidebarOpen ? (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.6"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              ) : (
                <svg
                  className="h-5 w-5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.6"
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              )}
            </button>

            {/* Breadcrumb */}
            <nav className="eyebrow hidden items-center gap-2 text-[#14213D]/55 sm:flex">
              <Link
                to="/admin/dashboard"
                className="transition hover:text-[#B8863B]"
              >
                Admin
              </Link>

              <span className="text-[#B8863B]">/</span>

              <span className="font-semibold text-[#14213D]">
                {formattedTitle}
              </span>
            </nav>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-3">
            <span className="eyebrow hidden items-center gap-2 border border-[#B8863B]/50 px-3 py-1.5 font-semibold text-[#B8863B] sm:inline-flex">
              <span className="h-1.5 w-1.5 animate-pulse bg-[#B8863B]" />
              Admin Portal
            </span>

            <Link
              to="/"
              className="eyebrow inline-flex items-center gap-2 border border-[#14213D] bg-[#14213D] px-3 py-2 font-semibold text-[#FFFDF9] transition hover:border-[#B8863B] hover:bg-[#B8863B] active:scale-95"
            >
              <svg
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="1.6"
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>

              <span className="hidden sm:inline">Live Site</span>
            </Link>
          </div>
        </header>

        {/* Content */}
        <main className="min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
